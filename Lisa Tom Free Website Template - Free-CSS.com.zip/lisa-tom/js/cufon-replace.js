Cufon.replace('h2, .nivo-controlNav a, .dropcap1, .button', { fontFamily: 'Josefin Sans', hover:true });
Cufon.replace('#menu li a, #menu_active, h1', { fontFamily: 'Tangerine', hover:true });
